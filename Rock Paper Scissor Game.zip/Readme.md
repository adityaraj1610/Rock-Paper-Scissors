# Rock-Paper-Scissors Game

This is a simple Java console application that allows you to play the classic Rock-Paper-Scissors game against the computer.

## How It Works

- The program prompts the user to enter their choice:
  - `0` for Rock
  - `1` for Paper
  - `2` for Scissors
- The computer randomly generates its choice.
- The game determines the winner based on the rules:
  - Rock beats Scissors
  - Paper beats Rock
  - Scissors beats Paper
- The program displays the result (Draw, You Win, or Computer Wins) and the computer's choice.

## Features

- Randomized computer choices using Java's `Random` class.
- Simple and intuitive input handling using `Scanner`.
- Clear and straightforward output for results.

## How to Run

1. Ensure you have [Java](https://www.oracle.com/java/technologies/javase-downloads.html) installed.
2. Clone this repository or download the `Game.java` file.
3. Compile the program:
   ```bash
   javac Game.java
